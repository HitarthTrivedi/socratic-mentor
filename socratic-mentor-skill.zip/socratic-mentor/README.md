# 🧠 Socratic Mentor — a Claude Code skill

**Make Claude teach you instead of doing your thinking for you.**

Socratic Mentor is a skill (connector) for [Claude Code](https://claude.com/claude-code) that flips Claude from an answer machine into a Socratic tutor. While it is active, Claude will **never hand you the finished answer**. Instead it:

- 🧭 Guides you with hints, first steps, and guiding questions
- 🗣️ Explains concepts in simple terms — just enough for you to make the next move yourself
- 🔎 Uses Claude's built-in web search to find **real, current learning resources**
- 🎥 Recommends **YouTube videos and full courses** (freeCodeCamp, MIT OCW, university lectures) with exact links — never invented URLs
- ❓ Ends every reply with one question that makes you think or try something
- 🪜 Gradually reveals more **only if you're genuinely stuck** after multiple real attempts

## Why

We've all gotten used to pasting a problem into an AI and copying out the solution. It's fast — and it quietly erodes the ability to solve problems on our own. Socratic Mentor exists to reverse that: it makes you work for the answer, the way a good human tutor would, while still giving you the best resources on the internet to learn from.

## Installation

A skill is just a folder containing a `SKILL.md` file. Install it in one of two places:

**For one project** (shared with everyone who clones the repo):

```bash
mkdir -p .claude/skills/socratic-mentor
cp SKILL.md .claude/skills/socratic-mentor/
```

**For yourself, in every project** (personal install):

```bash
mkdir -p ~/.claude/skills/socratic-mentor
cp SKILL.md ~/.claude/skills/socratic-mentor/
```

Then start a new Claude Code session (skills are discovered at session start).

## Usage

Activate it explicitly:

```
/socratic-mentor
```

…or just talk naturally — Claude auto-activates the skill when your request matches its description, e.g.:

> "Help me learn how neural networks work — but don't just tell me, teach me."

Once active, it stays on for the rest of the session. Every response follows this shape:

| Section | What you get |
|---|---|
| **Nudge** | A hint, first step, or reframing — in simple terms |
| **Learn from** | 2–3 real links from a live web search, always including a YouTube video/course when one exists |
| **Your move** | One question or small task to do before coming back |

## Deactivating

Say **"exit mentor mode"** in the session, or simply start a new session — the skill only applies while invoked.

## Example

> **You:** How do I reverse a linked list in Python?
>
> **Claude (Socratic Mentor):**
> **Nudge:** Think about what "reversing" means at the pointer level: every node's `next` must end up pointing at the node that came *before* it. You only need three variables to walk the list and flip those pointers one at a time. What would you call them?
>
> **Learn from:**
> - *Reverse a Linked List — visual walkthrough* — youtube.com/… — animates exactly the pointer flip you need
> - *NeetCode: Linked List course* — youtube.com/… — covers this and the 5 patterns built on it
> - *GeeksforGeeks: Reverse a linked list* — geeksforgeeks.org/… — diagrams + practice problems
>
> **Your move:** Draw three boxes on paper for nodes A→B→C and manually flip the arrows step by step. What state do your three variables need to be in *before* you flip B's pointer?

## How it works

Claude Code skills are markdown instruction files that load into Claude's context when invoked. This skill's `SKILL.md` contains the tutoring rules (never answer directly, search before recommending, one question per reply, gradual escape hatch) and leans on Claude Code's built-in `WebSearch`/`WebFetch` tools for live resource discovery — no API keys, no external services, nothing to configure.

## License

MIT — copy it, remix it, share it.
